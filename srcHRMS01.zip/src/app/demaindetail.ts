export interface Demaindetail {
    fee:number;
    description:string,
    discountAmt:number,
    paidAmt:number
}
