import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Demaindetail } from '../demaindetail';
import { catchError, retry } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class DatabaseService {
  WebAPI: string;
  profiles: any;
  headers: any;

  param: any;
  sidemenu:any;
  private subject = new Subject<any>();
  private profileData = new Subject<any>();
  PublicDomain: any;
  constructor(private http: HttpClient) {
    console.log('API Token Key: ',localStorage.getItem('AppTokenKey'));
    this.WebAPI = 'https://api.hrmsplus.in/api/'
    this.PublicDomain='hrms.bigapollospectra.com';
    // this.PublicDomain='localhost';
   }
  sendMenues(menu: any) {
    console.log(menu);
    this.subject.next(menu);
}
  getMenues(): Observable<any> {
    return this.subject.asObservable();
}
sendProfile(profile: any) {
  console.log(profile);
  this.profileData.next(profile);
}
getProfile(): Observable<any> {
  return this.profileData.asObservable();
}
  // isAlreadyLogin(param: any) {
  //   const res = this.http.post(this.WebAPI + 'Authentication/isAlreadyLogin', param);
  //   return res;
  // }

  login(param: any): Observable<any> {
    const res = this.http.post(this.WebAPI + 'Authentication/Login', param, this.httpOptions1);
    return res;
  }
  //https://api.hrmsplus.in/api/Employee/Profile?EmployeeCode=1002&DomainName=localhost&Token=B95AD3699D7D49308EA7838EEB988D34-1002

  getProfileData(param: any): Observable<any> {
    const res = this.http.get(this.WebAPI + `Employee/Profile?EmployeeCode=${param.EmpID}&DomainName=${this.PublicDomain}&Token=${localStorage.getItem('AppTokenKey')}`);
    return res;
  }

  checkIn(param: any): Observable<any> {
    const res = this.http.get(this.WebAPI + `Attendance/ValidateDevice?EmployeeCode=${param.EmpID}&DomainName=${this.PublicDomain}&Token=${localStorage.getItem('AppTokenKey')}`);
    return res;
  }

  GetLocation(param: any): Observable<any> {
    const res = this.http.get(this.WebAPI + `Employee/GetLocation?EmployeeCode=${param.EmpID}&DomainName=${this.PublicDomain}&Token=${localStorage.getItem('AppTokenKey')}`);
    return res;
  }
  ValidateCheckin(param: any): Observable<any> {
    const res = this.http.get(this.WebAPI + `Attendance/ValidateCheckin?EmployeeCode=${param.EmpID}&DomainName=${this.PublicDomain}&Token=${localStorage.getItem('AppTokenKey')}`);
    return res;
  }

  CheckoutApi(param: any): Observable<any> {
    const res = this.http.get(this.WebAPI + `Attendance/Checkout?EmployeeCode=${param.EmpID}&DomainName=${this.PublicDomain}&Token=${localStorage.getItem('AppTokenKey')}&AttendanceID=${localStorage.getItem('AttendanceID')}`);
    return res;
  }
  createAttendance(param: any): Observable<any> {
    const res = this.http.post(this.WebAPI + 'Attendance/Create', param, this.httpOptions1);
    return res;
  }
 
  OTPVarification(handler: any): Observable<any> {
    const res1 = this.http.post(this.WebAPI + 'Authentication/CheckOTP', handler);
    return res1;
  }
  GetHeader() {
    this.headers = new HttpHeaders();
    // alert(localStorage.getItem('AppTokenKey'));
    this.headers = this.headers.append('Authorization', 'Basic ' + localStorage.getItem('AppTokenKey'));
    this.headers = this.headers.append('Accept', 'application/json');
    this.headers = this.headers.append('Content-Type', 'application/x-www-form-urlencoded');
    // this.headers = this.headers.append('AppDomain ', 'ZWxlYXJuLnZpamF5c3R1ZHljaXJjbGUuY29t');
  }
  examlist(): Observable<any> {
    this.GetHeader();
    return this.http.get(this.WebAPI + 'Examination/ExamList', { headers: this.headers });
  }
  liveclasses(): Observable<any> {
    this.GetHeader();
    return this.http.get(this.WebAPI + 'LiveClasses/GetLiveClass', { headers: this.headers });
  }
  assignment(): Observable<any> {
    this.GetHeader();
    return this.http.get(this.WebAPI + 'Assignment/List', { headers: this.headers });
  }
  fee(): Observable<any> {
    this.GetHeader();
    return this.http.get(this.WebAPI + 'LiveClasses/GetLiveClass', { headers: this.headers });
  }
  studymaterial(): Observable<any> {
    this.GetHeader();
    return this.http.get(this.WebAPI + 'Assignment/StudyMaterial', { headers: this.headers });
  }
  vidoclass(): Observable<any> {
    this.GetHeader();
    return this.http.get(this.WebAPI + 'Assignment/VideoClasses', { headers: this.headers });
  }
  examresult(): Observable<any> {
    this.GetHeader();
    return this.http.get(this.WebAPI + 'Examination/GetResultSummry', { headers: this.headers });
  }
  profile(): Observable<any> {
    this.GetHeader();
    const res1 = this.http.get(this.WebAPI + 'Student/Profile', { headers: this.headers });
    return res1;
  }
  menuList(): Observable<any> {
    this.GetHeader();
    const res1 = this.http.get(this.WebAPI + 'Apps/Menus', { headers: this.headers });
    return res1;
  }
  examEnroll(param: any): Observable<any> {
    this.GetHeader();
    const res = this.http.post(this.WebAPI + 'Examination/Enroll', param, { headers: this.headers });
    return res;
  }
  makeAttendance(param: any): Observable<any> {
    this.GetHeader();
    const res = this.http.post(this.WebAPI + 'LiveClasses/MakeAttendance', param, { headers: this.headers });
    return res;
  }
  examquestion(): Observable<any> {
    this.GetHeader();
    var param = {
      enroll_id: localStorage.getItem('enroll_id')
    }
    const res = this.http.get(this.WebAPI + 'Examination/QuestionList', { headers: this.headers, params: param });
    return res;
  }
  AnswerSubmit(param) {
    this.GetHeader();
    return this.http.post(this.WebAPI + 'Examination/SubmitAnswer', param, { headers: this.headers });
  }
  PhotoAnswerSubmit(param) {
    this.GetHeader();
    return this.http.post(this.WebAPI + 'Examination/SubmitSinglePhotoAnswer', param, { headers: this.headers });
  }
  PhotoAnswerRemove(param) {
    this.GetHeader();
    return this.http.post(this.WebAPI + 'Examination/RemoveSinglePhotoAnswer', param, { headers: this.headers });
  }
  PreviewQuestion(_param): Observable<any> {
    this.GetHeader();
    const res1 = this.http.get(this.WebAPI + 'Examination/PreviewQuestionList', { headers: this.headers, params: _param });
    return res1;
  }
  PreviewQuestion_Photo(_param): Observable<any> {
    this.GetHeader();
    const res1 = this.http.get(this.WebAPI + 'Examination/PreviewPhotoQuestionList', { headers: this.headers, params: _param });
    return res1;
  }
  ExamSubmit(_param): Observable<any> {
    this.GetHeader();
    const res1 = this.http.get(this.WebAPI + 'Examination/ExamSubmit', { headers: this.headers, params: _param });
    return res1;
  }
  GetSubmitedAnswer(_param): Observable<any> {
    this.GetHeader();
    const res1 = this.http.get(this.WebAPI + 'Examination/GetSubmitedAnswer', { headers: this.headers, params: _param });
    return res1;
  }
  GetSetting(){
    this.GetHeader();
    const res = this.http.get(this.WebAPI + 'School/GetSetting', { headers: this.headers})
    return res;
  }
  GetSMSBox(){
    this.GetHeader();
    const res = this.http.get(this.WebAPI + 'School/GetSMS', { headers: this.headers})
    return res;
  }
  SetSMSRead(param) {
    this.GetHeader();
    return this.http.post(this.WebAPI + 'School/SetSMSRead', param, { headers: this.headers });
  }
  GetDemandList(){
    this.GetHeader();
    const res = this.http.get(this.WebAPI + 'Demand/DemandList', { headers: this.headers})
    return res;
  }
  GetDemandDetail(_param): Observable<Demaindetail[]>{
    this.GetHeader();
    const res = this.http.get<Demaindetail[]>(this.WebAPI + 'Demand/DemandDetail', { headers: this.headers,params: _param})
    return res;
  }
  CreateDemandTrans(_param){
    this.GetHeader();
    const res = this.http.get(this.WebAPI + 'Demand/CreateDemandTrans', { headers: this.headers,params: _param})
    return res;
  }


  ///////////////////
  studentProfile(data: any): Observable<any> {
    return this.http.get<any>(this.WebAPI + 'Student/Profile',  this.httpOptions)
    .pipe(retry(0), catchError(this.handleError))
  }
  

  handleError(handleError: any): import("rxjs").OperatorFunction<any, any> {
    throw new Error('Method not implemented.');
  }

  httpOptions = {
    headers: new HttpHeaders({ 
      'Content-Type': 'application/x-www-form-urlencoded', 
      Authorization: 'Basic ' + localStorage.getItem('AppTokenKey')
     })
   };
   httpOptions1 = {
    headers: new HttpHeaders({ 
      'Content-Type': 'application/json'
     })
   };
}
