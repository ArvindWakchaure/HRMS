import { Component } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss']
})
export class TabsPage {

  constructor(private router:Router,private alertCtrl:AlertController) {}
  checkIn(){
    this.router.navigate(["/tabs/tab2"]);
  }
//   async Attendance(){
//  const alert = await this.alertCtrl.create({
//       header: 'Confirm!',
//       message: 'Do you want to Check In?',
//       buttons: [
//         {
//           text: 'Cancel',
//           handler: () => {
//             console.log('Confirm Cancel');
//           },
//         },
//         {
//           text: 'Okay',
//           handler: () => {
//             // this.router.navigate(['/login'])
//           },
//         },
//       ],
//     });
//     await alert.present();
//   }
}
