import { Component } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss']
})
export class TabsPage {
  showbutton: any;

  constructor(private router:Router,private alertCtrl:AlertController) {
    this.showbutton = localStorage.getItem('showbutton');
    console.log(this.showbutton);
    
    
  }
  checkIn(){
    this.router.navigate(["/tabs/tab2"]);
  }
  ionViewWillEnter() {
    setInterval(() => {
      this.showbutton = localStorage.getItem('showbutton');
      console.log(this.showbutton);
    }, 2000);
  }
//   async Attendance(){
//  const alert = await this.alertCtrl.create({
//       header: 'Confirm!',
//       message: 'Do you want to Check In?',
//       buttons: [
//         {
//           text: 'Cancel',
//           handler: () => {
//             console.log('Confirm Cancel');
//           },
//         },
//         {
//           text: 'Okay',
//           handler: () => {
//             // this.router.navigate(['/login'])
//           },
//         },
//       ],
//     });
//     await alert.present();
//   }
}
